<?php include('inc.php');


$wp->addbible();
?>
