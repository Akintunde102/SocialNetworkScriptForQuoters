<?php   include('inc.php');
if(!empty($_GET["fav"])) {
      $wp->fav();
}
?>