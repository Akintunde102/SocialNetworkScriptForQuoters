<?php include('inc.php');
$time = strtotime(date("Y-m-d H:i:s"));
$wp->display_infinite();