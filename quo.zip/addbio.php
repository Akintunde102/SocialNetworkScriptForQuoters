<?php include('inc.php'); $wp->addbio(); ?>
	
	