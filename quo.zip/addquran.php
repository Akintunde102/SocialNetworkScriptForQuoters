<?php include('inc.php');


$wp->addquran();
?>
