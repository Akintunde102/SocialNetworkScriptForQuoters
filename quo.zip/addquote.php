<?php include('inc.php'); $wp->addquote(); ?>
	
	