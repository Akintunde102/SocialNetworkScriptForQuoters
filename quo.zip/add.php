<?php include('inc.php');


$wp->formatquote();
?>
